﻿using BookingTennis.Provider.Provider;
using BookingTennis.Repository;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookingTennis.Provider
{
    public static class ServicesConfiguration
    {
        public static void AddProviderServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddRepositoryService(configuration);
            services.AddTransient<ITennisCourtsProvider, TennisCourtsProvider>();
            services.AddTransient<IUserProvider, UserProvider>();
            services.AddTransient<IBookingsProvider, BookingsProvider>();
        }
    }
}
