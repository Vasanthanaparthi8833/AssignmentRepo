﻿using BookingTennis.Common.Business_Entities;
using BookingTennis.Common.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookingTennis.Provider.Provider
{
    public interface IBookingsProvider
    {
        List<BookingModel> GetAll(SessionProviderModel model);
        ResponseModel Save(BookingModel model, SessionProviderModel sessionmodel);
        ResponseModel Edit(BookingModel model, SessionProviderModel sessionmodel);
        BookingModel GetByid(int id, SessionProviderModel model);
        ResponseModel CancelBooking(int id, SessionProviderModel model);

    }
}
