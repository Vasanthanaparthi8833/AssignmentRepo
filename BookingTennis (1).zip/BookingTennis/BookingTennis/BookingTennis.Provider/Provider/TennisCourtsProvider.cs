﻿using BookingTennis.Common.Business_Entities;
using BookingTennis.Repository.Models;
using BookingTennis.Repository.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookingTennis.Provider.Provider
{
    public class TennisCourtsProvider : ITennisCourtsProvider
    {

        private UnitOfWork unitOfWork = new UnitOfWork();

        public TennisCourtsProvider()
        {
        }

        public List<CourtModel> GetList()
        {
            List<CourtModel> model = new List<CourtModel>();
            try
            {
                var list = unitOfWork.Court.GetAll(x => x.IsDeleted == false).ToList();//
                if (list != null && list.Count > 0)
                {
                    foreach (var item in list)
                    {
                        CourtModel courtModel = new CourtModel()
                        {
                            CourtName = item.CourtName,
                            CourtId = item.CourtId,
                           IsDeleted = item.IsDeleted,
                        };
                        model.Add(courtModel);
                    }
                }
            }
            catch (Exception ex)
            {

            }
            return model;
        }

        public ResponseModel Save(CourtModel model)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                if (!unitOfWork.Court.Any(x => x.CourtName == model.CourtName))
                {
                    Court court = new Court();
                    court.CourtName = model.CourtName;
                    unitOfWork.Court.Insert(court);
                    unitOfWork.Save();
                    response.IsSuccess = true;
                    response.message = "New Tennis Court Added Successfully";

                }
                else
                {
                    response.IsSuccess = false;
                    response.message = "Tennis already exists with this name";
                }

            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.message = ex.Message;
            }
            return response;
        }

        public ResponseModel Edit(CourtModel model)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                var data = unitOfWork.Court.GetAll(x => x.CourtId == model.CourtId && x.IsDeleted == false).FirstOrDefault();
                if (data != null)
                {
                    data.CourtName = model.CourtName;
                    unitOfWork.Court.Update(data);
                    unitOfWork.Save();
                    response.IsSuccess = true;
                    response.message = "Tennis Updated successfully";

                }
                else
                {
                    response.IsSuccess = false;
                    response.message = "Tennis did not exist";
                }
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.message = ex.Message;
            }
            return response;
        }

        public CourtModel GetById(int id)
        {
            CourtModel model = new CourtModel();
            try
            {
                if (id > 0)
                {
                    var _temp = unitOfWork.Court.GetAll(x => x.CourtId == id && x.IsDeleted == false).FirstOrDefault();//
                    if (_temp != null)
                    {
                        model.CourtId = _temp.CourtId;
                        model.CourtName = _temp.CourtName;
                        model.IsDeleted = _temp.IsDeleted;
                    }
                }
            }
            catch (Exception ex) { }
            return model;
        }

        public ResponseModel Delete(int id)
        {
            ResponseModel model = new ResponseModel();
            try
            {
                if (id > 0)
                {
                    var data = unitOfWork.Court.GetAll(x => x.CourtId == id && x.IsDeleted == false).FirstOrDefault(); 
                    if (data != null)
                    {
                        data.IsDeleted = true;
                        unitOfWork.Court.Update(data);
                        unitOfWork.Save();
                        model.IsSuccess = true;
                        model.message = "Tennis Court Deleted Successfully";
                    }
                    else
                    {
                        model.IsSuccess = false;
                        model.message = "Tennis Court not Found";

                    }
                }
                else
                {
                    model.IsSuccess = false;
                    model.message = "Provide correct Id";
                }
            }
            catch (Exception ex)
            {
                model.IsSuccess = false;
                model.message = ex.Message;
            }
            return model;
        }
    }
}
