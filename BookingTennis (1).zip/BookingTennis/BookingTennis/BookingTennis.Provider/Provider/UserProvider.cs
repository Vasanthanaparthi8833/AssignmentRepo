﻿using BookingTennis.Common.Business_Entities;
using BookingTennis.Common.Utility;
using BookingTennis.Repository.Models;
using BookingTennis.Repository.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace BookingTennis.Provider.Provider
{
    public class UserProvider : IUserProvider
    {
        private UnitOfWork unitOfWork = new UnitOfWork();

        public UserProvider()
        {
        }
        public ResponseModel SignUp(UserTableModel model)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                if (!unitOfWork.UserTable.Any(x => x.Email == model.Email))
                {
                    UserTable userTable = new UserTable()
                    {
                        RoleId = (int)Enumeration.Role.user,//default
                        Username = model.Username,
                        Email = model.Email,
                        Password = model.Password
                    };
                    unitOfWork.UserTable.Insert(userTable);
                    unitOfWork.Save();
                    response.IsSuccess = true;
                    response.message = "User Registered Successfully";
                }
                else
                {
                    response.IsSuccess = false;
                    response.message = "user with this Email is already Registered";
                }
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.message = ex.Message;
            }
            return response;

        }


        public ResponseModel LogIn(UserTableModel model)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                var data = unitOfWork.UserTable.GetAll(x => x.Email.ToLower() == model.Email.ToLower()).FirstOrDefault();
                if (data != null)
                {
                    if (data.Password == model.Password)
                    {
                        response.IsSuccess = true;
                        response.message = "LogIn Successful";
                        response.UserId = data.UserId;
                        response.UserName = data.Username;
                        response.RoleId = data.RoleId;
                    }
                    else
                    {
                        response.IsSuccess = false;
                        response.message = "Password Incorrect";
                    }
                }
                else
                {
                    response.IsSuccess = false;
                    response.message = "User not found";
                }

            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.message = ex.Message;
            }
            return response;
        }

    }
}
