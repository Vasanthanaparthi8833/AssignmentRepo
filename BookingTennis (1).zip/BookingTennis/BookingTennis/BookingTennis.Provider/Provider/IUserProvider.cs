﻿using BookingTennis.Common.Business_Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookingTennis.Provider.Provider
{
    public interface IUserProvider
    {
        ResponseModel SignUp(UserTableModel model);
        ResponseModel LogIn(UserTableModel model);
    }
}
