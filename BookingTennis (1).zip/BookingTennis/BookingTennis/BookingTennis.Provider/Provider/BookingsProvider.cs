﻿using BookingTennis.Common.Business_Entities;
using BookingTennis.Common.Utility;
using BookingTennis.Repository.Models;
using BookingTennis.Repository.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace BookingTennis.Provider.Provider
{
    public class BookingsProvider : IBookingsProvider
    {
        private UnitOfWork unitOfWork = new UnitOfWork();

        public BookingsProvider()
        {
        }

        public List<BookingModel> GetAll(SessionProviderModel model)
        {
            List<BookingModel> bookings = new List<BookingModel>();
            try
            {
                var _temp = unitOfWork.Booking.GetAll(x => x.UserId == model.UserId).ToList();
                if (_temp != null && _temp.Count > 0)
                {
                    foreach (var item in _temp)
                    {
                        BookingModel bookingModel = new BookingModel()
                        {
                            BookingId = item.BookingId,
                            BookingDate = item.BookingDate,
                            UserId = item.UserId,
                            CourtId = item.CourtId,
                            IsCanceled = item.IsCanceled,
                        };
                    }
                }
            }
            catch (Exception ex)
            {

            }
            return bookings;
        }

        public ResponseModel Save(BookingModel model, SessionProviderModel sessionmodel)
        {
            ResponseModel responseModel = new ResponseModel();
            try
            {
                if (unitOfWork.Court.Any(x => x.CourtId == model.CourtId && x.IsDeleted == false))//
                {
                    if (unitOfWork.Booking.Any(x => x.CourtId == model.CourtId && x.BookingDate == model.BookingDate && x.IsCanceled == false))//
                    {
                        responseModel.IsSuccess = false;
                        responseModel.message = "Tennis Court is already booked on that day.";
                        return responseModel;
                    }
                    Booking booking = new Booking()
                    {
                        UserId = sessionmodel.UserId,
                        CourtId = model.CourtId,
                        BookingDate = model.BookingDate,
                    };
                    unitOfWork.Booking.Insert(booking);
                    unitOfWork.Save();
                    responseModel.IsSuccess = true;
                    responseModel.message = "Booking Added Successfully.";
                }
                else
                {
                    responseModel.IsSuccess = false;
                    responseModel.message = "Tennis Court did not exists with this CourtId.";
                }


            }
            catch (Exception ex)
            {
            }
            return responseModel;
        }
        public ResponseModel Edit(BookingModel model, SessionProviderModel sessionmodel)
        {
            ResponseModel responseModel = new ResponseModel();
            try
            {
                if (unitOfWork.Court.Any(x => x.CourtId == model.CourtId && x.IsDeleted == false))//
                {
                    var data = unitOfWork.Booking.GetAll(x => x.BookingId == model.BookingId && x.UserId == sessionmodel.UserId && x.IsCanceled != true).FirstOrDefault();//
                    if (data != null)
                    {
                        data.BookingDate = model.BookingDate;
                        data.CourtId = model.CourtId;
                        unitOfWork.Booking.Update(data);
                        unitOfWork.Save();
                        responseModel.IsSuccess = true;
                        responseModel.message = "Booking Updated Successfully.";
                    }
                    else
                    {
                        responseModel.IsSuccess = false;
                        responseModel.message = "Tennis Court did not exists with this CourtId.";
                    }
                }
                else
                {
                    responseModel.IsSuccess = false;
                    responseModel.message = "Tennis Court did not exists with this CourtId.";
                }
            }
            catch (Exception ex) { }
            return responseModel;
        }

        public BookingModel GetByid(int id, SessionProviderModel sessionmodel)
        {
            BookingModel model = new BookingModel();
            try
            {
                var data = unitOfWork.Booking.GetAll(x => x.BookingId == id && x.UserId == sessionmodel.UserId).FirstOrDefault();
                if (data != null)
                {
                    model.CourtId = data.CourtId;
                    model.BookingId = data.BookingId;
                    model.BookingDate = data.BookingDate;
                    model.UserId = data.UserId;
                    model.IsCanceled = data.IsCanceled;
                }
            }
            catch (Exception ex)
            {
            }
            return model;
        }
        public ResponseModel CancelBooking(int id, SessionProviderModel model)
        {
            ResponseModel responseModel = new ResponseModel();
            try
            {
                var data = unitOfWork.Booking.GetAll(x => x.BookingId == id && x.UserId == model.UserId).FirstOrDefault();
                if (data != null)
                {
                    if (data.IsCanceled == false)
                    {
                        data.IsCanceled = true;
                        unitOfWork.Booking.Update(data);
                        unitOfWork.Save();
                        responseModel.IsSuccess = true;
                        responseModel.message = "Booking  canceled successfully.";

                    }
                    else
                    {
                        responseModel.IsSuccess = false;
                        responseModel.message = "Booking is already canceled.";
                    }
                }
                else
                {
                    responseModel.IsSuccess = false;
                    responseModel.message = "Booking did not exists with this BookingId.";
                }
            }
            catch (Exception ex)
            {
                responseModel.IsSuccess = false;
                responseModel.message = ex.Message;
            }
            return responseModel;
        }


    }
}
