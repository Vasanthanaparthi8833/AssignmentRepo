﻿using BookingTennis.Common.Business_Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookingTennis.Provider.Provider
{
    public interface ITennisCourtsProvider
    {
        List<CourtModel> GetList();
        ResponseModel Save(CourtModel model);
        ResponseModel Edit(CourtModel model);
        CourtModel GetById(int id);
        ResponseModel Delete(int id);
    }
}
