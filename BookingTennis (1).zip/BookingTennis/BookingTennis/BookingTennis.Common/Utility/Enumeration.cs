﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookingTennis.Common.Utility
{
    public class Enumeration
    {
        public enum Role
        {
            Admin = 1,
            user=2,
        }
    }
}
