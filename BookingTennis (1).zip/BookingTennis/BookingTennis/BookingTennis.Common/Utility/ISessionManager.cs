﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookingTennis.Common.Utility
{
    public interface ISessionManager
    {
        int UserId { get; set; }
        string Username { get; set; }
        int RoleId { get; set; }
        string GetSessionId();
        void ClearSession();
        string GetIP();
    }
}
