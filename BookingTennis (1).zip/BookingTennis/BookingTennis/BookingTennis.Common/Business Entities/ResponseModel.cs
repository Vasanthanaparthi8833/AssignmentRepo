﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookingTennis.Common.Business_Entities
{
    public class ResponseModel
    {
        public bool IsSuccess { get; set; }
        public string message { get; set; }
        public string UserName { get; set; }
        public int UserId { get; set; }
        public int RoleId { get; set; }
        public string JwtToken { get; set; }
    }
}
