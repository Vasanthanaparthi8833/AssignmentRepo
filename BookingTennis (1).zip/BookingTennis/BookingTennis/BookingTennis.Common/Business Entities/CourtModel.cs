﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookingTennis.Common.Business_Entities
{
    public class CourtModel
    {
        public int CourtId { get; set; }
        public string CourtName { get; set; } = null!;
        public bool IsDeleted { get; set; }
    }
}
