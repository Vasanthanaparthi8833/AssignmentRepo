﻿using BookingTennis.Common.Business_Entities;
using BookingTennis.Common.Utility;
using BookingTennis.Provider.Provider;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BookingTennis.api.Controllers
{

    [ApiController]
    [Route("api/[Controller]/[Action]")]
    [Authorize]
    public class BookingsController : BaseController
    {
        private IBookingsProvider _BookingsProvider;
        public BookingsController(IBookingsProvider BookingsProvider, ISessionManager sessionManager) : base(sessionManager)
        {
            _BookingsProvider = BookingsProvider;
        }

        [HttpGet]
        public IActionResult GetList()
        {
            List<BookingModel> list = new List<BookingModel>();
            list = _BookingsProvider.GetAll(GetSessionProviderParameters());
            return Ok(list);
        }

        [HttpPost]
        public IActionResult AddBooking(BookingModel model)
        {
            ResponseModel response = new ResponseModel();
            response = _BookingsProvider.Save(model,GetSessionProviderParameters());
            return Ok(response);
        }
        [HttpPost]
        public IActionResult Edit(BookingModel model)
        {
            ResponseModel response = new ResponseModel();
            response = _BookingsProvider.Edit(model, GetSessionProviderParameters());
            return Ok(response);
        }
        [HttpPost]
        public IActionResult CanceleBooking(int id)
        {
            ResponseModel response = new ResponseModel();
            response = _BookingsProvider.CancelBooking(id, GetSessionProviderParameters());
            return Ok(response);
        }

        [HttpGet]
        public IActionResult GetBoking(int id)
        {
            BookingModel model = new BookingModel();
            model = _BookingsProvider.GetByid(id, GetSessionProviderParameters());
            return Ok(model);
        }
    }
}
