﻿using BookingTennis.Common.Business_Entities;
using BookingTennis.Common.Utility;
using BookingTennis.Provider.Provider;
using BookingTennis.Repository.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.Drawing.Imaging;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace BookingTennis.api.Controllers
{

    [ApiController]
    [Route("api/[Controller]/[Action]")]
    public class UsersController : BaseController
    {
        private IUserProvider _UserProvider;
        private readonly IConfiguration _configuration;

        public UsersController(IUserProvider UserProvider, ISessionManager sessionManager, IConfiguration configuration) : base(sessionManager)
        {
            _UserProvider = UserProvider;
            _configuration = configuration;
        }

        [HttpPost]
        public IActionResult registe(UserTableModel model)
        {
            ResponseModel response = new ResponseModel();
            response = _UserProvider.SignUp(model);
            return Ok(response);
        }

        [HttpPost]
        public IActionResult login(UserTableModel model)
        {
            ResponseModel response = new ResponseModel();
            response = _UserProvider.LogIn(model);
            if (response.IsSuccess)
            {
                _sessionManager.UserId = response.UserId;
                _sessionManager.RoleId = response.RoleId;
                _sessionManager.Username = response.UserName;

                var AuthClaims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name,model.Username),
                    new Claim(JwtRegisteredClaimNames.Jti,Guid.NewGuid().ToString())
                };
                var authSigninKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(_configuration["JWT:Secrete"]));
                var token = new JwtSecurityToken(
                    issuer: _configuration["JWT:ValidIssuer"],
                    audience: _configuration["JWT:ValidAudience"],
                    expires: DateTime.Now.AddHours(8),
                    claims: AuthClaims,
                    signingCredentials: new SigningCredentials(authSigninKey, SecurityAlgorithms.HmacSha256Signature)
                    );
                response.JwtToken=  new JwtSecurityTokenHandler().WriteToken(token);
            }
            return Ok(response);
        }
    }
}
