﻿using BookingTennis.Common.Utility;
using Microsoft.AspNetCore.Mvc;

namespace BookingTennis.api.Controllers
{
    public class BaseController : Controller
    {

        public ISessionManager _sessionManager;
        public BaseController(ISessionManager sessionManager)
        {
            _sessionManager = sessionManager;
        }
        [NonAction]
        protected SessionProviderModel GetSessionProviderParameters()
        {
            SessionProviderModel sessionProviderModel = new SessionProviderModel
            {
                UserId = _sessionManager.UserId,
                Username = _sessionManager.Username,
                RoleId = _sessionManager.RoleId,
            };
            return sessionProviderModel;
        }
    }
}
