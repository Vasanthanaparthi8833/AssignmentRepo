﻿using BookingTennis.Common.Business_Entities;
using BookingTennis.Common.Utility;
using BookingTennis.Provider.Provider;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BookingTennis.api.Controllers
{
    [ApiController]
    [Route("api/[Controller]/[Action]")]
    [Authorize]
    public class TennisCourtsController : BaseController
    {
        private ITennisCourtsProvider _TennisCourtsProvider;
        public TennisCourtsController(ITennisCourtsProvider TennisCourtsProvider, ISessionManager sessionManager) : base(sessionManager)
        {
            _TennisCourtsProvider = TennisCourtsProvider;
        }


        [HttpGet]
        public IActionResult GetList()
        {
            List<CourtModel> courtModels = new List<CourtModel>();
            courtModels = _TennisCourtsProvider.GetList();
            return Ok(courtModels);
        }
        [HttpGet]
        public IActionResult Get(int id)
        {
            CourtModel model = new CourtModel();
            model = _TennisCourtsProvider.GetById(id);
            return Ok(model);
        }

        [HttpPost]
        public IActionResult Add(CourtModel model)
        {
            ResponseModel response = new ResponseModel();
            if (GetSessionProviderParameters().RoleId == (int)Enumeration.Role.Admin)
                response = _TennisCourtsProvider.Save(model);
            else
                return Unauthorized();
            return Ok(response);
        }
        [HttpPost]
        public IActionResult Edit(CourtModel model)
        {
            ResponseModel response = new ResponseModel();
            if (GetSessionProviderParameters().UserId == (int)Enumeration.Role.Admin)
                response = _TennisCourtsProvider.Edit(model);
            else
                return Unauthorized();

            return Ok(response);
        }

        [HttpPost]
        public IActionResult Delete(int id)
        {
            ResponseModel response = new ResponseModel();
            if (GetSessionProviderParameters().UserId == (int)Enumeration.Role.Admin)
                response = _TennisCourtsProvider.Delete(id);
            else
                return Unauthorized();
            return Ok(response);
        }
    }
}
