﻿using System;
using System.Collections.Generic;

namespace BookingTennis.Repository.Models
{
    public partial class Court
    {
        public Court()
        {
            Bookings = new HashSet<Booking>();
        }

        public int CourtId { get; set; }
        public string CourtName { get; set; } = null!;
        public bool IsDeleted { get; set; }

        public virtual ICollection<Booking> Bookings { get; set; }
    }
}
