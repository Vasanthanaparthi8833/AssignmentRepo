﻿using System;
using System.Collections.Generic;

namespace BookingTennis.Repository.Models
{
    public partial class Booking
    {
        public int BookingId { get; set; }
        public int UserId { get; set; }
        public int CourtId { get; set; }
        public DateTime BookingDate { get; set; }
        public bool IsCanceled { get; set; }

        public virtual Court Court { get; set; } = null!;
        public virtual UserTable User { get; set; } = null!;
    }
}
