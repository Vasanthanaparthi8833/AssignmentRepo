﻿using System;
using System.Collections.Generic;

namespace BookingTennis.Repository.Models
{
    public partial class UserTable
    {
        public UserTable()
        {
            Bookings = new HashSet<Booking>();
        }

        public int UserId { get; set; }
        public int RoleId { get; set; }
        public string Username { get; set; } = null!;
        public string Email { get; set; } = null!;
        public string Password { get; set; } = null!;

        public virtual Role Role { get; set; } = null!;
        public virtual ICollection<Booking> Bookings { get; set; }
    }
}
