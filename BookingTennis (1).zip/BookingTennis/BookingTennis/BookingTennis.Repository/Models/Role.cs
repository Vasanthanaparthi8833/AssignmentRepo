﻿using System;
using System.Collections.Generic;

namespace BookingTennis.Repository.Models
{
    public partial class Role
    {
        public Role()
        {
            UserTables = new HashSet<UserTable>();
        }

        public int RoleId { get; set; }
        public string RoleName { get; set; } = null!;

        public virtual ICollection<UserTable> UserTables { get; set; }
    }
}
