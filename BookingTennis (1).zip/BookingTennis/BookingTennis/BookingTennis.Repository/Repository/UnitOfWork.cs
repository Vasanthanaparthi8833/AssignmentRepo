﻿using BookingTennis.Repository.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookingTennis.Repository.Repository
{
    public class UnitOfWork
    {

        private EmployeeDbContext context = new EmployeeDbContext();
        public void Save()
        {
            context.SaveChanges();
        }
        private GenericRepository<Booking> _Booking;
        private GenericRepository<Court> _Court;
        private GenericRepository<Role> _Role;
        private GenericRepository<UserTable> _UserTable;

        public GenericRepository<Booking> Booking
        {
            get
            {
                if (_Booking == null)
                    _Booking = new GenericRepository<Booking>(context);
                return _Booking;
            }
        }

        public GenericRepository<Court> Court
        {
            get
            {
                if (_Court == null)
                    _Court = new GenericRepository<Court>(context);
                return _Court;
            }
        }
        public GenericRepository<Role> Role
        {
            get
            {
                if (_Role == null)
                    _Role = new GenericRepository<Role>(context);
                return _Role;
            }
        }

        public GenericRepository<UserTable> UserTable
        {
            get
            {
                if (_UserTable == null)
                    _UserTable = new GenericRepository<UserTable>(context);
                return _UserTable;
            }
        }
    }

}
